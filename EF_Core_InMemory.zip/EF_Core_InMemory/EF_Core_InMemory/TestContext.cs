﻿using EF_Core_InMemory.DAL;
using Microsoft.EntityFrameworkCore;
using System;

namespace EF_Core_InMemory
{
    public class TestContext : DbContext
    {
        public TestContext(DbContextOptions<TestContext> options) : base(options) { }

        public DbSet<Person> People { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            // Base Logic
            base.OnModelCreating(builder);

            #region Set DateTimeKind On Retrieval
            builder.Entity<Person>()
                .Property(o => o.Birthday)
                .HasConversion(v => v, v => DateTime.SpecifyKind(v, DateTimeKind.Utc));

            /*
            foreach (var entity in builder.Model.GetEntityTypes())
            {
                foreach (var prop in entity.GetProperties())
                {
                    if (prop.ClrType == typeof(DateTime))
                    {
                        builder.Entity(entity.ClrType)
                         .Property<DateTime>(prop.Name)
                         .HasConversion(
                          v => v,
                          v => DateTime.SpecifyKind(v, DateTimeKind.Utc));
                    }
                    else if (prop.ClrType == typeof(DateTime?))
                    {
                        builder.Entity(entity.ClrType)
                         .Property<DateTime?>(prop.Name)
                         .HasConversion(
                          v => v,
                          v => v.HasValue ? DateTime.SpecifyKind(v.Value, DateTimeKind.Utc) : v);
                    }
                }
            }*/
            #endregion
        }
    }
}