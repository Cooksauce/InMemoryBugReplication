﻿using EF_Core_InMemory.DAL;
using System;

namespace EF_Core_InMemory
{
    public class App
    {
        public void Run()
        {
            var context = ContextFactory.CreateTestContext();

            var person = new Person()
            {
                Birthday = new DateTime(2015, 1, 10)
            };

            context.People.Add(person);
            context.SaveChanges();

            var foundPerson = context.People.Find(person.Id);

            Console.WriteLine($"Person datetime kind (should value convert to Utc): {foundPerson.Birthday.Kind.ToString()}");
            Console.ReadLine();
        }
    }
}