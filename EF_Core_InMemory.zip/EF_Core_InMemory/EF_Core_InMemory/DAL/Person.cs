﻿using System;

namespace EF_Core_InMemory.DAL
{
    public class Person
    {
        public long Id { get; set; }
        public DateTime Birthday { get; set; }
    }
}