﻿using Microsoft.EntityFrameworkCore;
using System;

namespace EF_Core_InMemory
{
    public static class ContextFactory
    {
        public static TestContext CreateTestContext()
        {
            var optionsBuilder = new DbContextOptionsBuilder<TestContext>();

            optionsBuilder
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .UseLazyLoadingProxies();

            return new TestContext(optionsBuilder.Options);
        }
    }
}