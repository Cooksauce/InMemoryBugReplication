﻿using System;

namespace EF_Core_InMemory
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            new App().Run();
        }
    }
}